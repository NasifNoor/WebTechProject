<?php
function loadFromFile(){
	global $cred;
	$file=fopen("member.txt","r")or die("error");
	while($line=fgets($file)){
		$line=trim($line);
		$cr=explode(" ",$line);
		$dar=array("userName"=>$cr[0], "password"=>$cr[1]);
		$cred[]=$dar;
	}
	fclose($file);
}
function loadFromXML(){
	global $cred;
	$xml=simplexml_load_file("admin.xml") or die("Error: Cannot create object");
	foreach($xml as $ad){
		$dar=array();
		$dar["userName"]=(string)$ad->UserName;
		$dar["name"]=(string)$ad->Name;
		$dar["password"]=(string)$ad->Pass;
		$cred[]=$dar;
	}
}
?>