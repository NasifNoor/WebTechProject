<?php
$file=fopen('member.txt','a') or die("fle open error");

print_r($_REQUEST);
$c=0;
if(strlen($_REQUEST["userName"])>0){
	$c=fwrite($file,"\r\n");
	$c+=fwrite($file,$_REQUEST["userName"]);
	$c+=fwrite($file," ");
	$c+=fwrite($file,$_REQUEST["password"]);
	echo $c." characters added to file";
    header("Location: newLog.html");
}
else{
	echo $c." characetrs written";
}
?>


