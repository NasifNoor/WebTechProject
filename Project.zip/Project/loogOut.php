<?php
header("Location: newLog.html");
?>