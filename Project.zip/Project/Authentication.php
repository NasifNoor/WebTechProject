<?php
require("Function.php");
$cred=array();
loadFromFile();
loadFromXML();
$uname=$_REQUEST["u"];
$pass=$_REQUEST["p"];
print_r($_REQUEST);
print_r($cred);

foreach($cred as $a){
	if($uname==$a["userName"])
    {
        if($pass==$a["password"])
        {
            if($uname=="A1"){
                header("Location: Profile.html");
            }
            else
                header("Location: newPro.html");
        }
    }
}
?>